package me.andy_.challenges.player;

import me.andy_.challenges.Challenges;
import me.andy_.challenges.challenge.ChallengeGroup;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class TrackerGroup {

    public static String GUI_TITLE = "Challenges";

    private final ChallengeGroup group; // Probably doesn't need storing beyond instantiation
    private final Tracker[] trackers;
    private final Inventory gui;

    public TrackerGroup(ChallengeGroup group, Tracker[] trackers, Player player) {
        this.group = group;
        this.trackers = trackers;

        gui = Bukkit.createInventory(null, 54, GUI_TITLE);

        for (int i = 0; i < trackers.length; i++) {
            gui.setItem(i, trackers[i].getDisplayItem(player));
        }
    }

    public ChallengeGroup getChallengeGroup() {
        return group;
    }

    public Tracker[] getTrackers() {
        return trackers;
    }

    Inventory getGUI() {
        return gui;
    }

}
