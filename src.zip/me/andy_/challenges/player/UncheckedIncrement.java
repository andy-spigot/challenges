package me.andy_.challenges.player;

import org.bukkit.Statistic;

public class UncheckedIncrement {

    private final Statistic statistic;
    private final Object subStatistic;

    public UncheckedIncrement(Statistic statistic, Object subStatistic) {
        this.statistic = statistic;
        this.subStatistic = subStatistic;
    }

    public Statistic getStatistic() {
        return statistic;
    }

    public Object getSubStatistic() {
        return subStatistic;
    }

}
