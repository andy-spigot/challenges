package me.andy_.challenges.player;

import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashSet;
import java.util.Set;

public class PlayerManager {

    private boolean loading = true, saving = false;
    private TrackerGroup[] groups;
    private int currentGroup = 0;
    private final Set<UncheckedIncrement> uncheckedIncrements = new HashSet<>();

    public boolean isAccessible() {
        return !loading && !saving;
    }

    public void setSaving() {
        saving = true;
    }

    public TrackerGroup[] getTrackerGroups() {
        return groups;
    }

    public void setTrackerGroups(TrackerGroup[] groups) {
        this.groups = groups;

        // for every group
        for (int i = 0; i < groups.length; i++) {
            // add this group's display item to every group's GUI
            for (TrackerGroup g : groups) {
                ItemStack item = groups[i].getChallengeGroup().getDisplayItem();
                ItemMeta meta = item.getItemMeta();
                meta.setDisplayName(groups[i].getChallengeGroup().getName());
                meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_POTION_EFFECTS);
                item.setItemMeta(meta);

                g.getGUI().setItem(i + 45, item);
            }
        }

        this.loading = false;
    }

    public TrackerGroup getCurrentGroup() {
        return groups[currentGroup];
    }

    // tries to return a Tracker for a slot in a GUI
    public Tracker getTracker(int slot) {
        try {
            return groups[currentGroup].getTrackers()[slot];
        } catch (ArrayIndexOutOfBoundsException e) {
            return null;
        }
    }

    // Opens a TrackerGroup's GUI
    public void openGroup(Player player, int index) {
        if (currentGroup == index) return; // This TrackerGroup's GUI is already open

        try {
            player.openInventory(groups[index].getGUI());
            currentGroup = index;
        } catch (ArrayIndexOutOfBoundsException ignored) {}
    }

    // Checks if inv is the open GUI
    public boolean isCurrentGUI(Inventory inv) {
        return groups[currentGroup].getGUI().equals(inv);
    }

    // Opens the GUI of the TrackerGroup that was last viewed by player
    // Always call this method to open the GUI to correctly track currentGroup
    public void openGUI(Player player) {
        TrackerGroup g = groups[currentGroup];

        // Updating display items if statistic/stage/unclaimed have changed
        for (int i = 0; i < g.getTrackers().length; i++) {
            if (g.getTrackers()[i].updateDisplay()) {
                g.getGUI().setItem(i, g.getTrackers()[i].getDisplayItem(player));
            }
        }

        player.openInventory(groups[currentGroup].getGUI());
    }

    public synchronized void addUncheckedIncrement(UncheckedIncrement uncheckedIncrement) {
        this.uncheckedIncrements.add(uncheckedIncrement);
    }

    public synchronized Set<UncheckedIncrement> getUncheckedIncrementsCopy() {
        Set<UncheckedIncrement> copy = new HashSet<>(this.uncheckedIncrements);
        this.uncheckedIncrements.clear();
        return copy;
    }

}
