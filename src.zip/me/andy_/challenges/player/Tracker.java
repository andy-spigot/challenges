package me.andy_.challenges.player;

import me.andy_.challenges.Challenges;
import me.andy_.challenges.challenge.Challenge;
import me.andy_.challenges.challenge.reward.Reward;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class Tracker {

    public static String CHALLENGE_TITLE, CHALLENGE_COMPLETE, CHALLENGE_PROGRESS, REWARDS_TITLE, UNCLAIMED_REWARDS_TITLE, REWARD, STAGE_COMPLETE, REWARDS_CLAIMED;

    private final Challenge challenge;
    private int stage, unclaimed;
    private boolean updateDisplay = false;

    public Tracker(Challenge challenge, int stage, int unclaimed) {
        this.challenge = challenge;
        this.stage = stage;
        this.unclaimed = unclaimed;
    }

    public Challenge getChallenge() {
        return challenge;
    }

    public int getStage() {
        return stage;
    }

    public int getUnclaimedStage() {
        return unclaimed;
    }

    public void setUpdateDisplay() {
        updateDisplay = true;
    }

    public void attemptIncrement(Player player) {
        if (!this.isMaxStage() && this.isStageCompleted(stage, challenge.getPlayerStatistic(player))) {
            player.sendMessage(STAGE_COMPLETE.replace("%challenge", challenge.getName()).replace("%stage", (stage + 1) + ""));

            if (unclaimed == -1) {
                unclaimed = stage;
            }

            stage++;
        }
    }

    private boolean isMaxStage() {
        return stage == challenge.getStages().length - 1;
    }

    private boolean isStageCompleted(int stage, int amount) {
        if (stage == challenge.getStages().length - 1) {
            return false;
        } else return amount >= challenge.getStages()[stage].getRequirement();
    }

    public void claimReward(Player player) {
        for (Reward reward : challenge.getStages()[unclaimed].getRewards()) {
            reward.claim(player);
        }

        player.sendMessage(REWARDS_CLAIMED.replace("%challenge", challenge.getName()).replace("%stage", (unclaimed + 1) + ""));

        // Incrementing unclaimed if following stage's requirement has already been achieved, otherwise set to -1
        if (this.isStageCompleted(unclaimed + 1, challenge.getPlayerStatistic(player))) {
            unclaimed++;
        } else unclaimed = -1;

        updateDisplay = true;
    }

    boolean updateDisplay() {
        return updateDisplay;
    }

    ItemStack getDisplayItem(Player player) {
        ItemStack item = new ItemStack(challenge.getDisplayItem());
        ItemMeta meta = item.getItemMeta();
        ArrayList<String> lore = new ArrayList<>();
        lore.add("");

        // Name and progress
        if (this.isMaxStage()) {
            meta.setDisplayName(CHALLENGE_TITLE.replace("%challenge", challenge.getName()).replace("%stage", CHALLENGE_COMPLETE));
            lore.add(CHALLENGE_PROGRESS.replace("%progress", challenge.getPlayerStatistic(player) + ""));
        } else {
            meta.setDisplayName(CHALLENGE_TITLE.replace("%challenge", challenge.getName()).replace("%stage", (stage + 1) + ""));
            lore.add(CHALLENGE_PROGRESS.replace("%progress", challenge.getPlayerStatistic(player) + "/" + challenge.getStages()[stage].getRequirement()));
        }

        // Rewards
        if (!this.isMaxStage()) {
            List<String> previews = challenge.getStages()[stage].getRewardPreviews();

            if (previews.size() != 0) {
                lore.add("");
                lore.add(REWARDS_TITLE);

                for (String preview : previews)
                    lore.add(REWARD.replace("%reward", preview));
            }
        }

        // unclaimed rewards
        if (unclaimed != -1) {
            List<String> previews = challenge.getStages()[unclaimed].getRewardPreviews();

            if (previews.size() != 0) {
                lore.add("");
                lore.add(UNCLAIMED_REWARDS_TITLE);

                for (String preview : previews)
                    lore.add(REWARD.replace("%reward", preview));
            }
        }

        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_POTION_EFFECTS);
        item.setItemMeta(meta);

        return item;
    }

}
