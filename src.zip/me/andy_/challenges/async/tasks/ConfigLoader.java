package me.andy_.challenges.async.tasks;

import me.andy_.challenges.Challenges;
import me.andy_.challenges.challenge.Challenge;
import me.andy_.challenges.challenge.ChallengeGroup;
import me.andy_.challenges.challenge.Stage;
import me.andy_.challenges.challenge.reward.CommandReward;
import me.andy_.challenges.challenge.reward.ExperienceReward;
import me.andy_.challenges.challenge.reward.ItemReward;
import me.andy_.challenges.challenge.reward.Reward;
import me.andy_.challenges.player.Tracker;
import me.andy_.challenges.player.TrackerGroup;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public class ConfigLoader implements Runnable {

    private final Challenges plugin;

    public ConfigLoader(Challenges plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        if (!plugin.getDataFolder().exists())
            plugin.getDataFolder().mkdir();

        plugin.saveDefaultConfig();

        TrackerGroup.GUI_TITLE = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("gui_title", "&aChallenges"));
        Tracker.CHALLENGE_TITLE = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("challenge_title", "&a%challenge %stage"));
        Tracker.CHALLENGE_COMPLETE = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("challenge_complete", "&rCOMPLETE"));
        Tracker.CHALLENGE_PROGRESS = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("challenge_progress", "&r%progress"));
        Tracker.REWARDS_TITLE = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("rewards_title", "&aRewards"));
        Tracker.UNCLAIMED_REWARDS_TITLE = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("unclaimed_rewards_title", "&aUnclaimed rewards"));
        Tracker.REWARD = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("reward", "&r%reward"));
        Tracker.STAGE_COMPLETE = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("stage_complete", "&aYou completed %challenge %stage!"));
        Tracker.REWARDS_CLAIMED = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("rewards_claimed", "&aYou claimed rewards for %challenge %stage!"));

        List<ChallengeGroup> groups = new ArrayList<>();
        File[] groupFiles = plugin.getDataFolder().listFiles(new GroupFilenameFilter());

        if (groupFiles.length == 0) {
            plugin.saveResource("exampleGroup1.yml", false);
            plugin.saveResource("exampleGroup2.yml", false);
            groupFiles = plugin.getDataFolder().listFiles(new GroupFilenameFilter());
        }

        for (File groupFile : groupFiles) {
            YamlConfiguration groupConfig = YamlConfiguration.loadConfiguration(groupFile);
            List<Challenge> challenges = new ArrayList<>();

            for (String id : groupConfig.getConfigurationSection("challenges").getKeys(false)) {
                String[] idSplit = id.split("-");
                Statistic statistic;
                Object subStatistic = null;

                try {
                    statistic = Statistic.valueOf(idSplit[0]);
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().log(Level.INFO, "Unknown statistic {0}", idSplit);
                    continue;
                }

                if (statistic.getType() != Statistic.Type.UNTYPED) {
                    if (idSplit.length == 1) {
                        plugin.getLogger().log(Level.INFO, "No sub-statistic given for statistic {0}", idSplit);
                    } else {
                        try {
                            if (statistic.getType() == Statistic.Type.ENTITY) {
                                subStatistic = EntityType.valueOf(idSplit[1]);
                            } else {
                                Material material = Material.getMaterial(idSplit[1]);
                                if (material == null) {
                                    throw new Exception();
                                } else subStatistic = material;
                            }
                        } catch (Exception e) {
                            plugin.getLogger().log(Level.INFO, "Unknown sub-statistic {1} for statistic {0}", idSplit);
                            continue;
                        }
                    }
                }

                List<Stage> stages = new ArrayList<>();

                for (String stage : groupConfig.getStringList("challenges." + id + ".stages")) {
                    String[] stageSplit = stage.split(" ");
                    List<Reward> rewards = new ArrayList<>();

                    for (int i = 1; i < stageSplit.length; i++) {
                        String[] rewardSplit = stageSplit[i].split("=", 2);

                        if (rewardSplit[0].equals("command")) {
                            rewards.add(new CommandReward(rewardSplit[1]));
                        } else if (rewardSplit[0].equals("experience")) {
                            rewards.add(new ExperienceReward(rewardSplit[1]));
                        } else if (rewardSplit[0].equals("item")) {
                            try {
                                rewards.add(new ItemReward(rewardSplit[1]));
                            } catch (Exception e) {
                                plugin.getLogger().log(Level.INFO, "Unknown {0} for challenge {1}", new Object[]{e.getMessage(), id});
                            }
                        } else {
                            plugin.getLogger().log(Level.INFO, "Unknown reward {0} for challenge {1}", new Object[]{rewardSplit[0], id});
                        }
                    }

                    stages.add(new Stage(Integer.parseInt(stageSplit[0]), rewards.toArray(new Reward[0])));
                }

                stages.add(new Stage());

                challenges.add(new Challenge(statistic,
                        subStatistic,
                        ChatColor.translateAlternateColorCodes('&', groupConfig.getString("challenges." + id + ".name", "NAME NOT CONFIGURED")),
                        this.getConfigMaterial(groupConfig, "challenges." + id + ".item"),
                        stages.toArray(new Stage[0])));
            }

            groups.add(new ChallengeGroup(ChatColor.translateAlternateColorCodes('&', groupConfig.getString("name", "NAME NOT CONFIGURED")),
                    this.getConfigMaterial(groupConfig, "item"),
                    challenges.toArray(new Challenge[0])));
        }

        plugin.setChallengeGroups(groups.toArray(new ChallengeGroup[0]));
        plugin.getLogger().info("Loaded configuration");

        plugin.getPlayerDataFolder().mkdir();

        List<Player> players = new ArrayList<>(plugin.getServer().getOnlinePlayers()); // Getting copy to prevent CME
        for (Player player : players)
            plugin.getExecutor().submit(new PlayerLoader(plugin, player));
    }

    private Material getConfigMaterial(YamlConfiguration config, String path) {
        String string = config.getString(path);

        if (string == null) {
            return Material.STONE;
        } else {
            Material material = Material.getMaterial(string.toUpperCase());
            return material == null ? Material.STONE : material;
        }
    }

    private static class GroupFilenameFilter implements FilenameFilter {

        @Override
        public boolean accept(File file, String name) {
            return name.endsWith(".yml") && !name.equals("config.yml");
        }

    }

}
