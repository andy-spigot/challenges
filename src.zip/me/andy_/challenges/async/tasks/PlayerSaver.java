package me.andy_.challenges.async.tasks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import me.andy_.challenges.Challenges;
import me.andy_.challenges.player.PlayerManager;
import me.andy_.challenges.player.Tracker;
import me.andy_.challenges.player.TrackerGroup;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.UUID;
import java.util.logging.Level;

public class PlayerSaver implements Runnable {

    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Challenges plugin;
    private final UUID uuid;
    private final PlayerManager playerManager;

    public PlayerSaver(Challenges plugin, UUID uuid, PlayerManager playerManager) {
        this.plugin = plugin;
        this.uuid = uuid;
        this.playerManager = playerManager;
    }

    @Override
    public void run() {
        playerManager.setSaving();

        File file = new File(plugin.getPlayerDataFolder(), uuid.toString() + ".json");

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.WARNING, "An error occurred whilst saving a player's data (UUID = {0})", uuid.toString());
                e.printStackTrace();
                return;
            }
        }

        JsonObject json = new JsonObject();

        for (TrackerGroup group : playerManager.getTrackerGroups()) {
            Tracker[] trackers = group.getTrackers();

            for (Tracker tracker : trackers) {
                json.addProperty(tracker.getChallenge().getID(), String.format("%d %d", tracker.getStage(), tracker.getUnclaimedStage()));
            }
        }

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(gson.toJson(json));
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "An error occurred whilst saving a player's data (UUID = {0})", uuid.toString());
            e.printStackTrace();
        }
    }

}
