package me.andy_.challenges.async.tasks;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import me.andy_.challenges.Challenges;
import me.andy_.challenges.challenge.Challenge;
import me.andy_.challenges.challenge.ChallengeGroup;
import me.andy_.challenges.player.PlayerManager;
import me.andy_.challenges.player.Tracker;
import me.andy_.challenges.player.TrackerGroup;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;

public class PlayerLoader implements Runnable {

    private static final Gson gson = new Gson();
    private final Challenges plugin;
    private final Player player;

    public PlayerLoader(Challenges plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
    }

    @Override
    public void run() {
        PlayerManager manager = new PlayerManager();
        plugin.getPlayerManagerMap().put(player, manager);

        File file = new File(plugin.getPlayerDataFolder(), player.getUniqueId().toString() + ".json");
        ChallengeGroup[] challengeGroups = plugin.getChallengeGroups();
        TrackerGroup[] trackerGroups = new TrackerGroup[challengeGroups.length];

        if (file.exists()) {
            JsonObject json;

            try (FileReader reader = new FileReader(file)) {
                json = gson.fromJson(reader, JsonObject.class);
            } catch (IOException e) {
                plugin.getLogger().log(Level.WARNING, "An error occurred whilst loading a player's data (UUID = {0})", player.getUniqueId().toString());
                e.printStackTrace();
                return;
            }

            for (int g = 0; g < challengeGroups.length; g++) {
                Challenge[] challenges = challengeGroups[g].getChallenges();
                Tracker[] trackers = new Tracker[challenges.length];

                for (int c = 0; c < challenges.length; c++) {
                    JsonElement data = json.get(challenges[c].getID());

                    if (data == null) {
                        int[] progress = this.getProgress(player, challenges[c]);
                        trackers[c] = new Tracker(challenges[c], progress[0], progress[1]);
                    } else {
                        String[] dataSplit = data.getAsString().split(" ");
                        trackers[c] = new Tracker(challenges[c], Integer.parseInt(dataSplit[0]), Integer.parseInt(dataSplit[1]));
                    }
                }

                trackerGroups[g] = new TrackerGroup(challengeGroups[g], trackers, player);
            }
        } else {
            for (int g = 0; g < challengeGroups.length; g++) {
                Challenge[] challenges = challengeGroups[g].getChallenges();
                Tracker[] trackers = new Tracker[challenges.length];

                for (int c = 0; c < challenges.length; c++) {
                    int[] progress = this.getProgress(player, challenges[c]);
                    trackers[c] = new Tracker(challenges[c], progress[0], progress[1]);
                }

                trackerGroups[g] = new TrackerGroup(challengeGroups[g], trackers, player);
            }
        }

        if (player.isOnline()) {
            manager.setTrackerGroups(trackerGroups);
            player.sendMessage(ChatColor.GREEN + "Your challenge progression has been loaded!");
        } else {
            plugin.getPlayerManagerMap().remove(player); // Remove if player has left since data load started (no need to save since there will be no changes)
        }
    }

    private int[] getProgress(Player player, Challenge challenge) {
        int stage = 0, unclaimed = -1;
        int amount = challenge.getPlayerStatistic(player);
        int requirement = challenge.getStages()[stage].getRequirement();

        while (stage < challenge.getStages().length && requirement != -1 && amount >= requirement) {
            stage++;
            requirement = challenge.getStages()[stage].getRequirement();
        }

        if (stage > 0) {
            unclaimed = 0;
        }

        return new int[]{stage, unclaimed};
    }

}
