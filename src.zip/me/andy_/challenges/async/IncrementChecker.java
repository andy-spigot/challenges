package me.andy_.challenges.async;

import me.andy_.challenges.Challenges;
import me.andy_.challenges.player.PlayerManager;
import me.andy_.challenges.player.Tracker;
import me.andy_.challenges.player.TrackerGroup;
import me.andy_.challenges.player.UncheckedIncrement;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.Set;
import java.util.logging.Level;

public class IncrementChecker extends Thread {

    private final Challenges plugin;
    private final long frequency;

    public IncrementChecker(Challenges plugin, long frequency) {
        this.plugin = plugin;
        this.frequency = frequency <= 0 ? 1000 : frequency;
    }

    @Override
    public void run() {
        long checkStartTime;

        while (plugin.isEnabled()) {
            checkStartTime = System.currentTimeMillis();

            for (Map.Entry<Player, PlayerManager> entry : plugin.getPlayerManagerMap().entrySet()) {
                Player player = entry.getKey();
                PlayerManager manager = entry.getValue();

                if (!manager.isAccessible()) continue;

                Set<UncheckedIncrement> uncheckedIncrements = manager.getUncheckedIncrementsCopy();

                for (UncheckedIncrement uncheckedIncrement : uncheckedIncrements) {
                    Tracker tracker = this.getTrackerOf(manager, uncheckedIncrement.getStatistic(), uncheckedIncrement.getSubStatistic());
                    if (tracker != null) {
                        tracker.setUpdateDisplay();
                        tracker.attemptIncrement(player);
                    }
                }
            }

            if (System.currentTimeMillis() - checkStartTime > frequency) {
                plugin.getLogger().log(Level.WARNING, "Increment checker ran behind by {0}ms!", System.currentTimeMillis() - checkStartTime); // Warning if increment checker can't keep up
            } else {
                try {
                    Thread.sleep(frequency - (System.currentTimeMillis() - checkStartTime));
                } catch (InterruptedException ignored) {}
            }
        }
    }

    private Tracker getTrackerOf(PlayerManager playerManager, Statistic statistic, Object subStatistic) {
        TrackerGroup[] groups = playerManager.getTrackerGroups();

        for (int g = 0; g < groups.length; g++) {
            Tracker[] trackers = groups[g].getTrackers();

            for (int t = 0; t < trackers.length; t++) {
                if (statistic == trackers[t].getChallenge().getStatistic() && (subStatistic == null || subStatistic == trackers[t].getChallenge().getSubStatistic())) {
                    return trackers[t];
                }
            }
        }

        return null;
    }

}
