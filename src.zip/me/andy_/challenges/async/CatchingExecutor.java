package me.andy_.challenges.async;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

import java.util.concurrent.*;

public class CatchingExecutor extends ThreadPoolExecutor {

    public CatchingExecutor(int maxPoolSize) {
        super(0,
                maxPoolSize < 1 ? Integer.MAX_VALUE : maxPoolSize,
                60L,
                TimeUnit.SECONDS,
                new SynchronousQueue<>(),
                new ThreadFactoryBuilder().setNameFormat("Challenges Thread %d").build());
    }

    @Override
    protected void afterExecute(Runnable r, Throwable t) {
        super.afterExecute(r, t);

        if (t == null && r instanceof Future<?>) {
            try {
                ((Future<?>) r).get();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
