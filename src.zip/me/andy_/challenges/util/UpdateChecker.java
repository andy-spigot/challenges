package me.andy_.challenges.util;

import me.andy_.challenges.Challenges;
import org.bukkit.Bukkit;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.logging.Level;

public abstract class UpdateChecker {

    // Update checker tutorial: https://www.spigotmc.org/wiki/creating-an-update-checker-that-checks-for-updates/

    public static void check(Challenges plugin) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            // URL contains only the version string for the latest release of Challenges
            try (InputStream stream = new URL("https://api.spigotmc.org/legacy/update.php?resource=65861").openStream(); Scanner scanner = new Scanner(stream)) {
                String current = plugin.getDescription().getVersion();
                String latest = scanner.next();

                if (!current.equalsIgnoreCase(latest)) {
                    plugin.getLogger().log(Level.INFO, "A new update ({1}) is available! (Currently running {0})", new String[]{current, latest});
                }
            } catch (IOException | NoSuchElementException e) {
                plugin.getLogger().warning("An error occurred whilst checking for updates: " + e.getMessage());
            }
        });
    }

}
