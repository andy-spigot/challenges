package me.andy_.challenges.challenge;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class ChallengeGroup {

    private final String name;
    private final Material material;
    private final Challenge[] challenges;

    public ChallengeGroup(String name, Material material, Challenge[] challenges) {
        this.name = name;
        this.material = material;
        this.challenges = challenges;
    }

    public String getName() {
        return name;
    }

    public ItemStack getDisplayItem() {
        return new ItemStack(material);
    }

    public Challenge[] getChallenges() {
        return challenges;
    }

}
