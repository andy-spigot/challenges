package me.andy_.challenges.challenge.reward;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class CommandReward extends Reward {

    private final String command;
    private String preview;

    public CommandReward(String data) {
        String[] split = data.split(",", 2);

        command = split[0].replaceAll("_", " ");

        if (split.length == 2)
            preview = ChatColor.translateAlternateColorCodes('&', split[1].replace("_", " "));
    }

    @Override
    public void claim(Player player) {
        player.getServer().dispatchCommand(player.getServer().getConsoleSender(), command.replaceAll("<player>", player.getName()));
    }

    @Override
    public boolean hasPreview() {
        return preview != null;
    }

    @Override
    public String getPreview() {
        return preview;
    }

}
