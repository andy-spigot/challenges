package me.andy_.challenges.challenge.reward;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public class ItemReward extends Reward {

    private final ItemStack item;

    // Item config format -> item=material,amount,name=item_name,lore=item|lore,enchantment=level
    public ItemReward(String data) throws Exception {
        String[] dataSplit = data.split(",");

        Material material = Material.getMaterial(dataSplit[0].toUpperCase());
        if (material == null)
            throw new Exception(String.format("material %s", dataSplit[0]));

        item = new ItemStack(material, Integer.parseInt(dataSplit[1]));

        if (dataSplit.length > 2) {
            ItemMeta meta = item.getItemMeta();

            for (int i = 2; i < dataSplit.length; i++) {
                String[] metaSplit = dataSplit[i].split("=", 2);

                if (metaSplit[0].equals("name")) {
                    meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', metaSplit[1].replaceAll("_", " ")));
                } else if (metaSplit[0].equals("lore")) {
                    List<String> lore = new ArrayList<>();

                    // Double back-slash required for escape character
                    for (String line : metaSplit[1].split("\\|"))
                        lore.add(ChatColor.translateAlternateColorCodes('&', line.replaceAll("_", " ")));

                    meta.setLore(lore);
                } else {
                    Enchantment e;

                    try {
                        e = Enchantment.getByKey(NamespacedKey.minecraft(metaSplit[0].toLowerCase()));
                    } catch (NoClassDefFoundError err) {
                        e = Enchantment.getByName(metaSplit[0].toUpperCase());
                    }

                    if (e == null) {
                        throw new Exception(String.format("enchantment %s", metaSplit[0]));
                    } else {
                        meta.addEnchant(e, Integer.parseInt(metaSplit[1]), true);
                    }
                }
            }

            item.setItemMeta(meta);
        }
    }

    @Override
    public void claim(Player player) {
        player.getInventory().addItem(item);
    }

    @Override
    public boolean hasPreview() {
        return true;
    }

    @Override
    public String getPreview() {
        if (item.getItemMeta().hasDisplayName()) {
            return item.getItemMeta().getDisplayName() + " " + ChatColor.WHITE + "x" + item.getAmount();
        } else {
            StringBuilder builder = new StringBuilder();

            for (String split : item.getType().name().split("_")) {
                builder.append(split.substring(0, 1) + split.substring(1).toLowerCase() + " ");
            }

            return builder.substring(0, builder.length() - 1) + " " + ChatColor.WHITE + "x" + item.getAmount();
        }
    }

}
