package me.andy_.challenges.challenge.reward;

import org.bukkit.entity.Player;

public class ExperienceReward extends Reward {

    private final int exp;

    public ExperienceReward(String data) {
        exp = Integer.parseInt(data);
    }

    @Override
    public void claim(Player player) {
        player.giveExp(exp);
    }

    @Override
    public boolean hasPreview() {
        return true;
    }

    @Override
    public String getPreview() {
        return exp + " EXP";
    }

}
