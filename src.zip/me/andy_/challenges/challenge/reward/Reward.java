package me.andy_.challenges.challenge.reward;

import org.bukkit.entity.Player;

public abstract class Reward {

    public abstract void claim(Player player);

    public abstract boolean hasPreview();

    public abstract String getPreview();

}
