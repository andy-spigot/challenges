package me.andy_.challenges.challenge;

import me.andy_.challenges.challenge.reward.Reward;

import java.util.ArrayList;
import java.util.List;

public class Stage {

    private final int requirement;
    private final Reward[] rewards;

    public Stage(int requirement, Reward[] rewards) {
        this.requirement = requirement;
        this.rewards = rewards;
    }

    // Dummy stage constructor
    public Stage() {
        requirement = -1;
        rewards = new Reward[0];
    }

    public int getRequirement() {
        return requirement;
    }

    public Reward[] getRewards() {
        return rewards;
    }

    public List<String> getRewardPreviews() {
        List<String> previews = new ArrayList<>();

        for (Reward reward : rewards) {
            if (reward.hasPreview())
                previews.add(reward.getPreview());
        }

        return previews;
    }

}
