package me.andy_.challenges.challenge;

import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class Challenge {

    private final Statistic statistic;
    private final Object subStatistic;
    private final String name;
    private final Material material;
    private final Stage[] stages;

    public Challenge(Statistic statistic, Object subStatistic, String name, Material material, Stage[] stages) {
        this.statistic = statistic;
        this.subStatistic = subStatistic;
        this.name = name;
        this.material = material;
        this.stages = stages;
    }

    public Statistic getStatistic() {
        return statistic;
    }

    public Object getSubStatistic() {
        return subStatistic;
    }

    public String getName() {
        return name;
    }

    public ItemStack getDisplayItem() {
        return new ItemStack(material);
    }

    public Stage[] getStages() {
        return stages;
    }

    // ALWAYS USE THIS METHOD TO GET PLAYER STATISTICS
    public int getPlayerStatistic(Player player) {
        if (statistic.getType() == Statistic.Type.UNTYPED) {
            return player.getStatistic(statistic);
        } else if (statistic.getType() == Statistic.Type.ENTITY) {
            return player.getStatistic(statistic, (EntityType) subStatistic);
        } else return player.getStatistic(statistic, (Material) subStatistic);
    }

    // Returns a name which is unique for all challenges
    public String getID() {
        if (statistic.getType() == Statistic.Type.UNTYPED) {
            return statistic.name();
        } else if (statistic.getType() == Statistic.Type.ENTITY) {
            return statistic.name() + "-" + ((EntityType) subStatistic).name();
        } else {
            return statistic.name() + "-" + ((Material) subStatistic).name();
        }
    }

}
