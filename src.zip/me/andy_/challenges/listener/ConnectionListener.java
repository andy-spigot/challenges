package me.andy_.challenges.listener;

import me.andy_.challenges.Challenges;
import me.andy_.challenges.async.tasks.PlayerLoader;
import me.andy_.challenges.async.tasks.PlayerSaver;
import me.andy_.challenges.player.PlayerManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class ConnectionListener extends AutoRegisteredListener {

    public ConnectionListener(Challenges plugin) {
        super(plugin);
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent e) {
        plugin.getExecutor().submit(new PlayerLoader(plugin, e.getPlayer()));
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent e) {
        PlayerManager playerManager = plugin.getPlayerManagerMap().remove(e.getPlayer());
        if (playerManager != null && playerManager.isAccessible()) plugin.getExecutor().submit(new PlayerSaver(plugin, e.getPlayer().getUniqueId(), playerManager));
    }

}
