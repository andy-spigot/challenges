package me.andy_.challenges.listener;

import me.andy_.challenges.Challenges;
import me.andy_.challenges.player.PlayerManager;
import me.andy_.challenges.player.UncheckedIncrement;
import org.bukkit.Statistic;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerStatisticIncrementEvent;

public class IncrementListener extends AutoRegisteredListener {

    public IncrementListener(Challenges plugin) {
        super(plugin);
    }

    @EventHandler
    public void onIncrement(PlayerStatisticIncrementEvent e) {
        PlayerManager pm = plugin.getPlayerManagerMap().get(e.getPlayer());
        if (pm == null || !pm.isAccessible())
            return;

        if (e.getStatistic().getType() == Statistic.Type.UNTYPED) {
            pm.addUncheckedIncrement(new UncheckedIncrement(e.getStatistic(), null));
        } else if (e.getStatistic().getType() == Statistic.Type.ENTITY) {
            pm.addUncheckedIncrement(new UncheckedIncrement(e.getStatistic(), e.getEntityType()));
        } else {
            pm.addUncheckedIncrement(new UncheckedIncrement(e.getStatistic(), e.getMaterial()));
        }
    }

}
