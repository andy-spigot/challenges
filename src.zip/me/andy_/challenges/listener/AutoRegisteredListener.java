package me.andy_.challenges.listener;

import me.andy_.challenges.Challenges;
import org.bukkit.event.Listener;

public abstract class AutoRegisteredListener implements Listener {

    protected final Challenges plugin;

    AutoRegisteredListener(Challenges plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

}
