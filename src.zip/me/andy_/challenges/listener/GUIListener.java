package me.andy_.challenges.listener;

import me.andy_.challenges.Challenges;
import me.andy_.challenges.player.PlayerManager;
import me.andy_.challenges.player.Tracker;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;

public class GUIListener extends AutoRegisteredListener {

    public GUIListener(Challenges plugin) {
        super(plugin);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        Player player = (Player) e.getWhoClicked();
        PlayerManager manager = plugin.getPlayerManagerMap().get(player);

        if (manager != null && manager.isAccessible()) {
            // If this inventory is a TrackerGroup's GUI and slot is in the GUI
            if (manager.isCurrentGUI(e.getInventory()) && e.getSlot() >= 0 && e.getSlot() < 54) {
                e.setCancelled(true);

                if (e.getSlot() >= 45) { // If slot represents a group slot
                    Bukkit.getScheduler().runTask(plugin, () -> manager.openGroup(player, e.getSlot() - 45));
                } else if (e.getSlot() < manager.getCurrentGroup().getTrackers().length) { // If slot represents a challenge slot
                    Tracker tracker = manager.getTracker(e.getSlot());

                    // Giving any unclaimed rewards to player
                    if (tracker.getUnclaimedStage() != -1) {
                        tracker.claimReward(player);
                        Bukkit.getScheduler().runTask(plugin, player::closeInventory);
                    }
                }
            }
        }
    }

}
