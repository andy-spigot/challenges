package me.andy_.challenges.commands;

import me.andy_.challenges.Challenges;
import org.bukkit.command.CommandExecutor;

public abstract class AutoRegisteredCommand implements CommandExecutor {

    protected final Challenges plugin;

    AutoRegisteredCommand(Challenges plugin, String command) {
        this.plugin = plugin;
        plugin.getCommand(command).setExecutor(this);
    }

}
