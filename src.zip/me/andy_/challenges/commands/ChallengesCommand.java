package me.andy_.challenges.commands;

import me.andy_.challenges.Challenges;
import me.andy_.challenges.player.PlayerManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ChallengesCommand extends AutoRegisteredCommand {

    public ChallengesCommand(Challenges plugin, String command) {
        super(plugin, command);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command!");
            return true;
        }

        Player player = (Player) sender;
        PlayerManager manager = plugin.getPlayerManagerMap().get(player);

        if (manager != null && manager.isAccessible()) {
            manager.openGUI(player);
        } else {
            player.sendMessage(ChatColor.RED + "Your challenge progression isn't loaded yet!");
        }

        return true;
    }

}
