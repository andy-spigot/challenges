package me.andy_.challenges;

import me.andy_.challenges.async.CatchingExecutor;
import me.andy_.challenges.async.IncrementChecker;
import me.andy_.challenges.async.tasks.ConfigLoader;
import me.andy_.challenges.async.tasks.PlayerSaver;
import me.andy_.challenges.challenge.ChallengeGroup;
import me.andy_.challenges.commands.ChallengesCommand;
import me.andy_.challenges.listener.ConnectionListener;
import me.andy_.challenges.listener.GUIListener;
import me.andy_.challenges.listener.IncrementListener;
import me.andy_.challenges.player.PlayerManager;
import me.andy_.challenges.util.MetricsLite;
import me.andy_.challenges.util.UpdateChecker;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

public class Challenges extends JavaPlugin {

    private IncrementChecker incrementChecker;
    private ExecutorService executor;
    private ChallengeGroup[] groups;

    private final File playerDataFolder = new File(this.getDataFolder(), "playerdata");
    private final Map<Player, PlayerManager> playerManagerMap = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        if (this.setup()) {
            new ConnectionListener(this);
            new GUIListener(this);
            new IncrementListener(this);

            new ChallengesCommand(this, "challenges");

            new MetricsLite(this);
            UpdateChecker.check(this);
        }
    }

    @Override
    public void onDisable() {
        if (incrementChecker != null)
            incrementChecker.interrupt();

        for (Map.Entry<Player, PlayerManager> entry : playerManagerMap.entrySet())
            executor.submit(new PlayerSaver(this, entry.getKey().getUniqueId(), entry.getValue()));

        // Forcing main thread to wait for all save tasks to return before stopping
        try {
            executor.shutdown(); // Required to prevent awaitTermination from blocking after tasks return
            executor.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private boolean setup() {
        if (this.getDataFolder().exists() && this.getConfig().getDouble("version") < 3.0) {
            this.getLogger().info("Your configuration files are incompatible with this version of Challenges!");
            this.getLogger().info("For more information: https://github.com/andy-spigot/challenges");
            this.getServer().getPluginManager().disablePlugin(this);
            return false;
        }

        incrementChecker = new IncrementChecker(this, this.getConfig().getLong("increment_checker_frequency", 1000));
        incrementChecker.start();

        executor = new CatchingExecutor(this.getConfig().getInt("executor_max_pool_size"));
        executor.submit(new ConfigLoader(this));

        return true;
    }

    public ExecutorService getExecutor() {
        return executor;
    }

    public ChallengeGroup[] getChallengeGroups() {
        return groups;
    }

    public void setChallengeGroups(ChallengeGroup[] groups) {
        this.groups = groups;
    }

    public File getPlayerDataFolder() {
        return playerDataFolder;
    }

    public Map<Player, PlayerManager> getPlayerManagerMap() {
        return playerManagerMap;
    }

}
